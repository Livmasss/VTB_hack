package com.livmas.vtb_hack.enums

enum class RouteModes(value: Int) {
    WALK(0),
    CAR(1)
}