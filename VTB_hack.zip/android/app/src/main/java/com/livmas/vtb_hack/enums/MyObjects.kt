package com.livmas.vtb_hack.enums

enum class MyObjects(value: Int) {
    START(0),
    END(1),
    ROUTE(2),
}